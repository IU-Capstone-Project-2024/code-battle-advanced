Sum
----------

Time limit: 2.0 second  
Memory limit: 64 MB  

Your task is to find the sum of all integer numbers lying between 1 and _N_ inclusive.

### Input

The input consists of a single integer _N_ that is not greater than 10000 by it's absolute value.

### Output

Write a single integer number that is the sum of all integer numbers lying between 1 and _N_ inclusive.

### Sample

| input | output |
|-------|--------|
| -3    |  -5    |   
