python3 $(dirname "$0")/checker.py $1 $2
